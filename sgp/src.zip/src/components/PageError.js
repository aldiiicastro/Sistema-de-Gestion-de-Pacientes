import React from "react";
import '../styles/PageError.css'

const PageError = () => {  
    return(
        <p>Hola Soy Una Pagina de Error</p>
    )
}

export default PageError;